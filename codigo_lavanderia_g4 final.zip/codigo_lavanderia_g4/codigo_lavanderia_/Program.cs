﻿using System;
using System.Collections.Generic;
using System.IO;//se utiliza para guardar en txt
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codigo_lavanderia_
{
    internal class Program
    {
        //aqui declaramos los arreglos globales
        //son globales porque podemos acceder desde cualquier metodo
        static string[] nombres = new string[101];
        static string[] estados = new string[101];
        static string[] pagos = new string[101];
        static double[] deuda = new double[101];
        static int[] cantidadPrendas = new int[101];
        static string[] opcion_servicio = new string[101];
        static string[] detallesPrenda = new string[101];

        //este es el main osea el metodo principal 
        static void Main(string[] args)
        {
            int ticket = 1;
            double total = 0;
            int opcion;

            // datos de prueba
            //iniciamos creando 5 arreglo con datos ya predefinidos
            string[] n = {
                "Ana Torres", "Luis Gomez", "Maria Rios", "Carlos Vega", "Sofia Paz",
                "Diego Luna", "Lucia Mora", "Pedro Salas", "Elena Cruz", "Jorge Diaz"
            };
            string[] e = { "En lavado", "Listo para recoger", "Recogido", "En lavado", "Listo para recoger" };
            string[] p = { "Pagado", "Pendiente", "Pagado", "Pagado", "Pendiente" };
            double[] d = { 0, 5.50, 0, 0, 3.50 };
            int[] prendas = { 3, 8, 5, 2, 12 };
            string[] os = { "Lavado al agua", "Lavado al seco", "Teñido", "Lavado al agua", "Lavado al seco" };
            string[] dp = { "Tiene detalles", "Sin detalles", "tiene una rotura", "esta rasgada la manga", "le falta un boton" };

            // === SECCIÓN PERSISTENCIA: LEER ARCHIVO TXT SI EXISTE ===
            string documentos = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string carpetaApp = Path.Combine(documentos, "MiSistemaDeControl");
            bool archivoCargado = false;

            if (Directory.Exists(carpetaApp))
            {
                // Buscamos el archivo de reporte más reciente en la carpeta de forma explícita
                DirectoryInfo directorio = new DirectoryInfo(carpetaApp);
                FileInfo[] archivos = directorio.GetFiles("reporte_*.txt");
                FileInfo ultimoArchivo = archivos.OrderByDescending(f => f.LastWriteTime).FirstOrDefault();

                if (ultimoArchivo != null)
                {
                    try
                    {
                        string[] lineas = File.ReadAllLines(ultimoArchivo.FullName);
                        int tActual = 0;

                        foreach (string linea in lineas)
                        {
                            if (linea.StartsWith("Ticket #"))
                            {
                                // Parseo seguro dividiendo la línea por el separador '|'
                                string[] partesCortadas = linea.Split('|');

                                // Ahora que el pago está en la misma línea, verificamos que tenga al menos 7 partes (índices 0 al 6)
                                if (partesCortadas.Length >= 7)
                                {
                                    string parteTicket = partesCortadas[0].Replace("Ticket #", "").Trim();
                                    if (int.TryParse(parteTicket, out tActual))
                                    {
                                        // Recuperamos los datos de las posiciones del Split limpiando etiquetas y espacios
                                        nombres[tActual] = partesCortadas[1].Trim();
                                        cantidadPrendas[tActual] = int.Parse(partesCortadas[2].Replace("cant.P:", "").Replace("cant.P: ", "").Trim());
                                        detallesPrenda[tActual] = partesCortadas[3].Replace("detalle:", "").Replace("detalle: ", "").Trim();
                                        opcion_servicio[tActual] = partesCortadas[4].Replace("T.servicio :", "").Trim();
                                        estados[tActual] = partesCortadas[5].Trim();

                                        // CORRECCIÓN DE LECTURA: Leemos el pago directamente de la posición 6 de la misma línea
                                        string partePago = partesCortadas[6].Trim();
                                        if (partePago.StartsWith("Falta S/."))
                                        {
                                            pagos[tActual] = "Pendiente";
                                            deuda[tActual] = double.Parse(partePago.Replace("Falta S/.", "").Trim());
                                        }
                                        else
                                        {
                                            pagos[tActual] = "Pagado";
                                            deuda[tActual] = 0;
                                        }

                                        if (tActual >= ticket) ticket = tActual + 1;
                                    }
                                }
                            }
                            else if (linea.StartsWith("Total recaudado:   S/."))
                            {
                                double.TryParse(linea.Replace("Total recaudado:   S/.", "").Trim(), out total);
                            }
                        }
                        archivoCargado = true;
                        Console.WriteLine("¡Se recuperaron los datos del último reporte guardado en disco con éxito!");
                        Console.WriteLine($"Continuando desde el Ticket #{ticket}. Presione una tecla...");
                        Console.ReadKey();
                    }
                    catch (Exception)
                    {
                        // Si falla la lectura por corrupción del archivo, el sistema iniciará en limpio con la carga base
                    }
                }
            }

            // Si no existía archivo previo, cargamos los 50 datos simulados por defecto
            if (!archivoCargado)
            {
                for (int i = 1; i <= 50; i++)
                {
                    // Usamos (i - 1) para alinear perfectamente los índices de los arreglos origen
                    nombres[i] = n[(i - 1) % 10]; //utilizamos el operador % para reiniciar el indice de n y llenar el espacio 11,12,13...
                    estados[i] = e[(i - 1) % 5];
                    pagos[i] = p[(i - 1) % 5];
                    deuda[i] = d[(i - 1) % 5];
                    cantidadPrendas[i] = prendas[(i - 1) % 5];
                    opcion_servicio[i] = os[(i - 1) % 5];
                    detallesPrenda[i] = dp[(i - 1) % 5];
                    // Calculamos la caja inicial de forma lógica basado en el pago real
                    if (pagos[i] == "Pagado")
                    {
                        total += 20.00; // Cliente pagó completo el servicio estimado
                    }
                    else if (pagos[i] == "Pendiente")
                    {
                        total += (20.00 - deuda[i]); // Entra a caja solo el adelanto (Tarifa - Lo que debe)
                    }
                }
                ticket = 51; //definimos el valor 51 para agregar un espacio para nuevos registros 
            }
            // --- FIN DATOS DE PRUEBA ---            
            do //iniciamos el bucle do-while
            {
                Console.Clear();
                Console.WriteLine("============================");
                Console.WriteLine("      SISTEMA MR. WASH      ");
                Console.WriteLine("============================");
                Console.WriteLine("1. Nuevo pedido");
                Console.WriteLine("2. Ver historial");
                Console.WriteLine("3. Confirmar recojo");
                Console.WriteLine("4. Cierre del dia");
                Console.WriteLine("5. Salir");
                Console.WriteLine("============================");
                Console.Write("Opcion: ");

                // Si ponen letras o números fuera del 1-5, se repite la pregunta
                while (int.TryParse(Console.ReadLine(), out opcion) == false || opcion < 1 || opcion > 5)
                {
                    Console.WriteLine("\n¡Error: Opcion no valida! Debe ingresar un numero del 1 al 5.");
                    Console.Write("Intente de nuevo: ");
                }

                switch (opcion)
                {
                    case 1:
                        NuevoPedido(ticket, ref total);
                        ticket++;
                        break;
                    case 2:
                        VerHistorial(ticket);
                        break;

                    case 3:
                        ConfirmarRecojo(ticket, ref total);
                        break;

                    case 4:
                        Console.Clear();
                        Console.WriteLine("===== CIERRE DEL DIA =====");
                        Console.WriteLine("Tickets atendidos: " + (ticket - 1));
                        Console.WriteLine("Total recaudado:   S/." + total.ToString("F2"));
                        Console.WriteLine("==========================");
                        Console.WriteLine("\nPresione una tecla...");
                        Console.ReadKey();
                        break;
                    case 5:
                        Console.Clear();
                        Console.WriteLine("Cerrando el sistema de forma segura...");

                        //  Obtenemos la ruta de Mis Documentos
                        documentos = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                        //  Definimos nuestra propia carpeta dentro de Documentos
                        carpetaApp = Path.Combine(documentos, "MiSistemaDeControl");

                        // Si la carpeta no existe 
                        if (!Directory.Exists(carpetaApp))
                        {
                            Directory.CreateDirectory(carpetaApp);
                        }

                        //  Creamos un nombre único usando la fecha y hora actual 
                        // Usamos guiones porque Windows no permite dos puntos  en los nombres de archivos
                        string fechaActual = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
                        string nombreArchivo = $"reporte_{fechaActual}.txt";

                        // Combinamos la carpeta propia con el nombre único del archivo
                        string rutaCompleta = Path.Combine(carpetaApp, nombreArchivo);

                        Console.WriteLine($"Generando reporte de control en: {rutaCompleta}...");

                        List<string> lineasReporte = new List<string>();
                        lineasReporte.Add("=== REPORTE DE CONTROL - CIERRE DE SISTEMA ===");
                        lineasReporte.Add("Fecha y hora de cierre: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        lineasReporte.Add($"Total recaudado:   S/.{total.ToString("F2")}");
                        lineasReporte.Add("-----------------------------------------------");
                        lineasReporte.Add("CLIENTES REGISTRADOS EN ESTA SESIÓN:");

                        for (int i = 1; i < nombres.Length; i++)
                        {
                            if (nombres[i] != null)
                            {
                                // CORRECCIÓN DE ESCRITURA: Ahora el estado del pago se añade al final de la misma línea usando el separador '|'
                                string textoPago = (pagos[i] == "Pendiente") ? "Falta S/." + deuda[i].ToString("F2") : "Pagado";

                                lineasReporte.Add("Ticket #" + i + "| " + nombres[i] + " |cant.P: " + cantidadPrendas[i] + " |detalle: " + detallesPrenda[i] + " |T.servicio :" + opcion_servicio[i] + " | " + estados[i] + " | " + textoPago + " |");
                                lineasReporte.Add("-------------------------------------------------------------------------------------");
                            }
                        }

                        try
                        {
                            //Guardamos el archivo con la ruta y nombre dinámicos
                            File.WriteAllLines(rutaCompleta, lineasReporte);
                            Console.WriteLine("\n¡Datos guardados con éxito en Documentos/MiSistemaDeControl!");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("\nError al guardar el archivo: " + ex.Message);
                        }

                        Console.WriteLine("\nGracias por usar el sistema. Presione cualquier tecla para salir...");
                        Console.ReadKey();
                        break;

                    default:
                        Console.WriteLine("Opción no válida. Intente de nuevo.");
                        Console.ReadKey();
                        break;
                }

            } while (opcion != 5);

            Console.WriteLine("Hasta luego!");
            Console.ReadKey();
        }

        // =============================================
        // REGISTRAR UN NUEVO PEDIDO
        // =============================================
        static void NuevoPedido(int ticket, ref double totalDia)
        {
            Console.Clear();
            Console.WriteLine("--- NUEVO PEDIDO  Ticket #" + ticket + " ---");

            string nombre;
            bool nombreInvalido;

            // BUCLE VALIDACIÓN NOMBRE: Repite si está vacío o si mete números
            do
            {
                nombreInvalido = false;
                Console.Write("Nombre del cliente: ");
                nombre = Console.ReadLine();

                // Validación 1: Verificar que no sea nulo, vacío, ni puros espacios en blanco
                if (string.IsNullOrWhiteSpace(nombre))
                {
                    nombreInvalido = true;
                    Console.WriteLine("¡Error: El nombre del cliente no puede quedar vacío!");
                    continue; // Se salta el resto del bucle y vuelve a preguntar
                }

                // Validación 2: Evitar que contenga números
                for (int i = 0; i < nombre.Length; i++)
                {
                    if (nombre[i] >= '0' && nombre[i] <= '9')
                    {
                        nombreInvalido = true;
                        break;
                    }
                }

                if (nombreInvalido == true)
                {
                    Console.WriteLine("¡Error: El nombre no puede contener numeros!");
                }

            } while (nombreInvalido == true);

            // BUCLE PARA PRENDAS: No avanza si ingresan letras o números negativos
            Console.Write("Cantidad de prendas: ");
            int prendas;
            while (int.TryParse(Console.ReadLine(), out prendas) == false || prendas <= 0)
            {
                Console.WriteLine("¡Error: Ingrese una cantidad de prendas valida (numeros mayores a 0)!");
                Console.Write("Cantidad de prendas: ");
            }

            // BUCLE PARA PESO: No avanza si ingresan letras o pesos menores o iguales a cero
            Console.Write("Peso en kg: ");
            double peso;
            while (double.TryParse(Console.ReadLine(), out peso) == false || peso <= 0)
            {
                Console.WriteLine("¡Error: Ingrese un peso valido (numeros mayores a 0)!");
                Console.Write("Peso en kg: ");
            }

            Console.WriteLine("________________________________");
            Console.WriteLine("\n¿La prenda tiene algún detalle / defecto?");
            Console.WriteLine("1. Sí");
            Console.WriteLine("2. No");
            Console.WriteLine("3. Especificar detalle personalizado");
            Console.Write("Seleccione una opción (1-3): ");

            string opcion = Console.ReadLine();
            // BUCLE DETALLES: Si escriben cualquier otra opción que no sea 1 2 3
            while (opcion != "1" && opcion != "2" && opcion != "3")
            {
                Console.WriteLine("¡Opción no válida!");
                Console.Write("Seleccione una opción (1-3): ");
                opcion = Console.ReadLine();
            }

            switch (opcion)
            {
                case "1":
                    detallesPrenda[ticket] = "Tiene detalles";
                    break;

                case "2":
                    detallesPrenda[ticket] = "Sin detalles";
                    break;

                case "3":
                    Console.WriteLine("Describa el detalle de la prenda (ej. Manchado, botón roto): ");
                    string detalle_esc = Console.ReadLine();
                    detallesPrenda[ticket] = detalle_esc;
                    break;
            }

            Console.Clear();
            Console.WriteLine("---SELECCION DE SERVICIO---");
            Console.WriteLine();
            Console.WriteLine("Tipo de servicio:");
            Console.WriteLine("  1. Lavado al agua  S/.5.00/kg");
            Console.WriteLine("  2. Lavado al seco  S/.8.00/kg");
            Console.WriteLine("  3. Teñido          S/.10.00/kg");
            Console.Write("Opcion: ");

            // BUCLE SERVICIO: Obliga a ingresar 1, 2 o 3 obligatoriamente
            int servOp;
            while (int.TryParse(Console.ReadLine(), out servOp) == false || servOp < 1 || servOp > 3)
            {
                Console.WriteLine("¡Error: Seleccione un servicio valido (1, 2 o 3)!");
                Console.Write("Opcion: ");
            }

            string servicio;
            double precio;

            //asignamos el valor o precio segun la opcion 
            if (servOp == 1) { servicio = "Lavado al agua"; precio = 5; }
            else if (servOp == 2) { servicio = "Lavado al seco"; precio = 8; }
            else { servicio = "Teñido"; precio = 10; }

            double totalPedido = peso * precio;
            double descuento = 0;

            if (totalPedido > 30)
            {
                descuento = totalPedido * 0.10;//se aplica el descuento
                totalPedido = totalPedido - descuento;
            }

            // BUCLE DÍAS: No avanza si ponen letras o días fuera del rango 1-30
            Console.Write("Dias estimados de entrega (1-30): ");
            int dias;
            while (int.TryParse(Console.ReadLine(), out dias) == false || dias < 1 || dias > 30)
            {
                Console.WriteLine("¡Error: Ingrese un numero de dias valido (1 a 30)!");
                Console.Write("Dias estimados de entrega (1-30): ");
            }

            Console.Clear();
            Console.WriteLine("Total a pagar: S/." + totalPedido.ToString("F2"));
            Console.Write("Monto que paga el cliente: S/."); //cuanto pago el cliente

            // BUCLE PAGO: No permite letras ni montos negativos
            double montoPago;
            while (double.TryParse(Console.ReadLine(), out montoPago) == false || montoPago < 0)
            {
                Console.WriteLine("¡Error: Ingrese un monto de dinero valido!");
                Console.Write("Monto que paga el cliente: S/.");
            }

            //declaramos variables vuelto y falta con 0 osea sin un monto definido
            double vuelto = 0;
            double falta = 0;
            string estadoPago;

            if (montoPago >= totalPedido)
            {
                vuelto = montoPago - totalPedido; //asignamos el vuelto 
                estadoPago = "Pagado"; // asignamos el estado 
                totalDia += totalPedido; // Se suma lo cobrado realmente a la caja general
            }
            else
            {
                //definimos el monto si es que falta pagar y asignamos el estado 
                falta = totalPedido - montoPago;
                estadoPago = "Pendiente";
                totalDia += montoPago; // Entra a caja únicamente el adelanto parcial otorgado
            }
            //codigo de boleta 
            Console.Clear();
            Console.WriteLine("================================");
            Console.WriteLine("          BOLETA DE PAGO         ");
            Console.WriteLine("================================");
            Console.WriteLine("Ticket:    #" + ticket);
            Console.WriteLine("Cliente:   " + nombre);
            Console.WriteLine("Servicio:  " + servicio);
            Console.WriteLine("Prendas:   " + prendas);
            Console.WriteLine("Detalle:   " + detallesPrenda[ticket]); // Corregido para que imprima la celda del arreglo, no el arreglo completo
            Console.WriteLine("Peso:      " + peso + " kg");
            Console.WriteLine("Descuento: S/." + descuento.ToString("F2"));
            Console.WriteLine("Total:     S/." + totalPedido.ToString("F2"));
            Console.WriteLine("Pago:      " + estadoPago);

            if (estadoPago == "Pagado")
                Console.WriteLine("Vuelto:    S/." + vuelto.ToString("F2"));
            else
                Console.WriteLine("Falta:     S/." + falta.ToString("F2"));

            Console.WriteLine("Entrega en " + dias + " dia(s)");
            Console.WriteLine("Estado:    En lavado");
            Console.WriteLine("================================");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
            // guardamos los datos en los arreglos segun el numero de tiket
            nombres[ticket] = nombre;
            estados[ticket] = "En lavado";
            cantidadPrendas[ticket] = prendas;
            pagos[ticket] = estadoPago;
            deuda[ticket] = falta;
            opcion_servicio[ticket] = servicio;
        }

        // =============================================
        // VER HISTORIAL DE TODOS LOS TICKETS
        // =============================================
        static void VerHistorial(int ticket)
        {
            Console.Clear();
            Console.WriteLine("===== HISTORIAL =====");
            //alerta si es que no hay datos, en este caso si hay datos de prueba
            if (ticket == 1)
            {
                Console.WriteLine("No hay pedidos aun.");
            }
            else
            {
                for (int i = 1; i <= ticket - 1; i++)
                {
                    Console.Write("Ticket #" + i + "|" + nombres[i] + "|cant.P: " + cantidadPrendas[i] + "|detalle: " + detallesPrenda[i] + "|T.servicio :" + opcion_servicio[i] + "|" + estados[i] + "|");

                    if (pagos[i] == "Pendiente")
                        Console.WriteLine("Falta S/." + deuda[i].ToString("F2"));
                    else
                        Console.WriteLine("Pagado");
                    Console.WriteLine("-------------------------------------------------------------------------------------");

                }
            }

            Console.WriteLine("=====================");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
        }

        // =============================================
        // CONFIRMAR RECOJO DE UN PEDIDO
        // =============================================
        static void ConfirmarRecojo(int ticket, ref double totalDia)
        {
            Console.Clear();
            Console.WriteLine("--- CONFIRMAR RECOJO ---");
            //alerta 
            if (ticket == 1)
            {
                Console.WriteLine("No hay pedidos aun.");
                Console.WriteLine("\nPresione una tecla...");
                Console.ReadKey();
                return;
            }

            Console.Write("Numero de ticket (1-" + (ticket - 1) + "): ");

            int num;
            // BUCLE TICKET: Obliga a meter un número y que además exista en el sistema
            while (int.TryParse(Console.ReadLine(), out num) == false || num < 1 || num >= ticket)
            {
                Console.WriteLine("\n¡Error: El número de ticket no es válido o no existe!");
                Console.Write("Ingrese un numero de ticket correcto (1-" + (ticket - 1) + "): ");
            }

            Console.Clear();
            Console.WriteLine("Ticket:  #" + num);
            Console.WriteLine("Cliente: " + nombres[num]);
            Console.WriteLine("Estado:  " + estados[num]);

            if (pagos[num] == "Pendiente")
                Console.WriteLine("Pago:    Falta S/." + deuda[num].ToString("F2"));
            else
                Console.WriteLine("Pago:    Pagado");

            Console.WriteLine("------------------------");

            if (estados[num] == "En lavado")
            {
                Console.WriteLine("1. Marcar como Listo para recoger");
                Console.WriteLine("2. Cancelar");
                Console.Write("Opcion: ");

                int op;
                // BUCLE RECOJO 1: Obliga a poner 1 o 2
                while (int.TryParse(Console.ReadLine(), out op) == false || (op != 1 && op != 2))
                {
                    Console.WriteLine("¡Error: Seleccione una opcion valida (1 o 2)!");
                    Console.Write("Opcion: ");
                }

                if (op == 1)
                {
                    estados[num] = "Listo para recoger";
                    Console.WriteLine("Actualizado: Listo para recoger");
                }
                else
                {
                    Console.WriteLine("Sin cambios.");
                }
            }
            else if (estados[num] == "Listo para recoger")
            {
                Console.WriteLine("1. Marcar como Recogido y pagado");
                Console.WriteLine("2. Sin cambios");
                Console.Write("Opcion: ");

                int op;
                // BUCLE RECOJO 2: Obliga a poner 1 o 2
                while (int.TryParse(Console.ReadLine(), out op) == false || (op != 1 && op != 2))
                {
                    Console.WriteLine("¡Error: Seleccione una opcion valida (1 o 2)!");
                    Console.Write("Opcion: ");
                }

                if (op == 1)
                {
                    estados[num] = "Recogido";
                    pagos[num] = "Pagado";
                    totalDia += deuda[num]; // Se suma la liquidación de la deuda a la caja real
                    deuda[num] = 0;
                    Console.WriteLine("Actualizado: Recogido y Pagado");
                }
                else
                {
                    Console.WriteLine("Sin cambios.");
                }
            }
            else if (estados[num] == "Recogido")
            {
                Console.WriteLine("Este pedido ya fue recogido.");
            }

            Console.WriteLine("------------------------");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
        }
    }
}