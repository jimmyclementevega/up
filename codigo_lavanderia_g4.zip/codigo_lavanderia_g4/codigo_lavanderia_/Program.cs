﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codigo_lavanderia_
{
    internal class Program
    {
        //aqui declaramos los arreglos globales
        //son globales porque podemos acceder desde cualquier metodo
        static string[] nombres = new string[101];
        static string[] estados = new string[101];
        static string[] pagos = new string[101];
        static double[] deuda = new double[101];
        static int[] cantidadPrendas = new int[101];
        
        //este es el main osea el metodo principal 
        static void Main(string[] args)
        {
            int ticket = 1;
            double total = 0;
            int opcion;

            // datos de prueba
            //iniciamos creando 5 arreglo con datos ya predefinidos
            string[] n = {
                "Ana Torres", "Luis Gomez", "Maria Rios", "Carlos Vega", "Sofia Paz",
                "Diego Luna", "Lucia Mora", "Pedro Salas", "Elena Cruz", "Jorge Diaz"
            };
            string[] e = { "En lavado", "Listo para recoger", "Recogido", "En lavado", "Listo para recoger" };
            string[] p = { "Pagado", "Pendiente", "Pagado", "Pagado", "Pendiente" };
            double[] d = { 0, 5.50, 0, 0, 3.50 };
            int[] prendas = {3, 8, 5, 2, 12 };

            for (int i = 1; i <= 50; i++)
            {
                // Usamos (i - 1) para alinear perfectamente los índices de los arreglos origen
                nombres[i] = n[(i - 1) % 10]; //utilizamos el operador % para reiniciar el indice de n y llenar el espacio 11,12,13...
                estados[i] = e[(i - 1) % 5];
                pagos[i] = p[(i - 1) % 5];
                deuda[i] = d[(i - 1) % 5];
                cantidadPrendas[i] = prendas[(i - 1) % 5];
                // Calculamos la caja inicial de forma lógica basado en el pago real
                if (pagos[i] == "Pagado")
                {
                    total += 20.00; // Cliente pagó completo el servicio estimado
                }
                else if (pagos[i] == "Pendiente")
                {
                    total += (20.00 - deuda[i]); // Entra a caja solo el adelanto (Tarifa - Lo que debe)
                }
            }

            ticket = 51; //definimos el valor 51 para agregar un espacio para nuevos registros 
            // --- FIN DATOS DE PRUEBA ---            
            do //iniciamos el bucle do-while
            {
                Console.Clear();
                Console.WriteLine("============================");
                Console.WriteLine("      SISTEMA MR. WASH      ");
                Console.WriteLine("============================");
                Console.WriteLine("1. Nuevo pedido");
                Console.WriteLine("2. Ver historial");
                Console.WriteLine("3. Confirmar recojo");
                Console.WriteLine("4. Cierre del dia");
                Console.WriteLine("5. Salir");
                Console.WriteLine("============================");
                Console.Write("Opcion: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        NuevoPedido(ticket, ref total);
                          ticket++;
                        break;
                    case 2:
                        VerHistorial(ticket);
                        break;

                    case 3 :
                        ConfirmarRecojo(ticket);

                        break;

                    case 4 :
                        Console.Clear();
                        Console.WriteLine("===== CIERRE DEL DIA =====");
                        Console.WriteLine("Tickets atendidos: " + (ticket - 1));
                        Console.WriteLine("Total recaudado:   S/." + total.ToString("F2"));
                        Console.WriteLine("==========================");
                        Console.WriteLine("\nPresione una tecla...");
                        Console.ReadKey();
                        break;
                    default:
                        break;
                }

            } while (opcion != 5);

            Console.WriteLine("Hasta luego!");
            Console.ReadKey();
        }

        // =============================================
        // REGISTRAR UN NUEVO PEDIDO
        // =============================================
        static void NuevoPedido(int ticket, ref double totalDia)
        {
            Console.Clear();
            Console.WriteLine("--- NUEVO PEDIDO  Ticket #" + ticket + " ---");

            Console.Write("Nombre del cliente: ");
            string nombre = Console.ReadLine();

            Console.Write("Cantidad de prendas: ");
            int prendas = int.Parse(Console.ReadLine());

            Console.Write("Peso en kg: ");
            double peso = double.Parse(Console.ReadLine());

            Console.WriteLine("Tipo de servicio:");
            Console.WriteLine("  1. Lavado al agua  S/.5.00/kg");
            Console.WriteLine("  2. Lavado al seco  S/.8.00/kg");
            Console.WriteLine("  3. Teñido          S/.10.00/kg");
            Console.Write("Opcion: ");
            int servOp = int.Parse(Console.ReadLine());//creamos la variable donde se almacena la opcion

            string servicio;
            double precio;

            //asignamos el valor o precio segun la opcion 
            if (servOp == 1) { servicio = "Lavado al agua"; precio = 5; }
            else if (servOp == 2) { servicio = "Lavado al seco"; precio = 8; }
            else { servicio = "Tenido"; precio = 10; }

            double totalPedido = peso * precio;
            double descuento = 0;

            if (totalPedido > 30)
            {
                descuento = totalPedido * 0.10;//se aplica el descuento
                totalPedido = totalPedido - descuento;
            }

            Console.Write("Dias estimados de entrega (1-30): ");
            int dias = int.Parse(Console.ReadLine());

            Console.Clear();
            Console.WriteLine("Total a pagar: S/." + totalPedido.ToString("F2"));
            Console.Write("Monto que paga el cliente: S/."); //cuanto pago el cliente
            double montoPago = double.Parse(Console.ReadLine());
            //declaramos variables vuelto y falta con 0 osea sin un monto definido
            double vuelto = 0;
            double falta = 0;
            string estadoPago;

            if (montoPago >= totalPedido)
            {
                vuelto = montoPago - totalPedido; //asignamos el vuelto 
                estadoPago = "Pagado"; // asignamos el estado 
            }
            else
            {  
                //definimos el monto si es que falta pagar y asignamos el estado 
                falta = totalPedido - montoPago;
                estadoPago = "Pendiente";
            }
            //codigo de boleta 
            Console.Clear();
            Console.WriteLine("================================");
            Console.WriteLine("         BOLETA DE PAGO         ");
            Console.WriteLine("================================");
            Console.WriteLine("Ticket:    #" + ticket);
            Console.WriteLine("Cliente:   " + nombre);
            Console.WriteLine("Servicio:  " + servicio);
            Console.WriteLine("Prendas:   " + prendas);
            Console.WriteLine("Peso:      " + peso + " kg");
            Console.WriteLine("Descuento: S/." + descuento.ToString("F2"));
            Console.WriteLine("Total:     S/." + totalPedido.ToString("F2"));
            Console.WriteLine("Pago:      " + estadoPago);

            if (estadoPago == "Pagado")
                Console.WriteLine("Vuelto:    S/." + vuelto.ToString("F2"));
            else
                Console.WriteLine("Falta:     S/." + falta.ToString("F2"));

            Console.WriteLine("Entrega en " + dias + " dia(s)");
            Console.WriteLine("Estado:    En lavado");
            Console.WriteLine("================================");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
            // guardamos los datos en los arreglos segun el numero de tiket
            nombres[ticket] = nombre;
            estados[ticket] = "En lavado";
            cantidadPrendas[ticket] = prendas;
            pagos[ticket] = estadoPago;
            deuda[ticket] = falta;
            totalDia += totalPedido;
        }

        // =============================================
        // VER HISTORIAL DE TODOS LOS TICKETS
        // =============================================
        static void VerHistorial(int ticket)
        {
            Console.Clear();
            Console.WriteLine("===== HISTORIAL =====");
            //alerta si es que no hay datos, en este caso si hay datos de prueba
            if (ticket == 1)
            {
                Console.WriteLine("No hay pedidos aun.");
            }
            else
            {
                for (int i = 1; i <= ticket - 1; i++)
                {
                    Console.Write("Ticket #" + i + " | " + nombres[i] + " | prendas : "+ cantidadPrendas[i] +" | "+ estados[i] + " | ");

                    if (pagos[i] == "Pendiente")
                        Console.WriteLine("Falta S/." + deuda[i].ToString("F2"));
                    else
                        Console.WriteLine("Pagado");
                }
            }

            Console.WriteLine("=====================");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
        }

        // =============================================
        // CONFIRMAR RECOJO DE UN PEDIDO
        // =============================================
        static void ConfirmarRecojo(int ticket)
        {
            Console.Clear();
            Console.WriteLine("--- CONFIRMAR RECOJO ---");
            //alerta 
            if (ticket == 1)
            {
                Console.WriteLine("No hay pedidos aun.");
                Console.WriteLine("\nPresione una tecla...");
                Console.ReadKey();
                return;
            }

            Console.Write("Numero de ticket (1-" + (ticket - 1) + "): ");
            int num = int.Parse(Console.ReadLine());
           
            Console.Clear();
            Console.WriteLine("Ticket:  #" + num);
            Console.WriteLine("Cliente: " + nombres[num]);
            Console.WriteLine("Estado:  " + estados[num]);

            if (pagos[num] == "Pendiente")
                Console.WriteLine("Pago:    Falta S/." + deuda[num].ToString("F2"));
            else
                Console.WriteLine("Pago:    Pagado");

            Console.WriteLine("------------------------");

            if (estados[num] == "En lavado")
            {
                Console.WriteLine("1. Marcar como Listo para recoger");
                Console.WriteLine("2. Cancelar");
                Console.Write("Opcion: ");
                int op = int.Parse(Console.ReadLine());

                if (op == 1)
                {
                    estados[num] = "Listo para recoger";
                    Console.WriteLine("Actualizado: Listo para recoger");
                }
                else
                {
                    Console.WriteLine("Sin cambios.");
                }
            }
            else if (estados[num] == "Listo para recoger")
            {
                Console.WriteLine("1. Marcar como Recogido y pagado");
                Console.WriteLine("2. Sin cambios");
                Console.Write("Opcion: ");
                int op = int.Parse(Console.ReadLine());

                if (op == 1)
                {
                    estados[num] = "Recogido";
                    pagos[num] = "Pagado";
                    deuda[num] = 0;
                    Console.WriteLine("Actualizado: Recogido y Pagado");
                }
                else
                {
                    Console.WriteLine("Sin cambios.");
                }
            }
            else if (estados[num] == "Recogido")
            {
                Console.WriteLine("Este pedido ya fue recogido.");
            }

            Console.WriteLine("------------------------");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
        }
    }
}