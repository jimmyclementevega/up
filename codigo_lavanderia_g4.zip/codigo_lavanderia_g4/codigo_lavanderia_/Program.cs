﻿using System;
using System.Collections.Generic;
using System.IO; // se utiliza para guardar en txt
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace codigo_lavanderia_
{
    internal class Program
    {

        // LISTAS DINÁMICAS GLOBALES ===
        static List<string> nombres = new List<string>();
        static List<string> estados = new List<string>();
        static List<string> pagos = new List<string>();
        static List<double> deuda = new List<double>();
        static List<int> cantidadPrendas = new List<int>();
        static List<string> opcion_servicio = new List<string>();
        static List<string> detallesPrenda = new List<string>();

        static void Main(string[] args)
        {
            // Inicializamos la posición 0 con datos vacíos para que los tickets reales empiecen en 1
            AlineadorIndiceCero();

            int ticket = 1;
            double total = 0;
            int opcion;

            // Datos base de prueba
            string[] n = { "Ana Torres", "Luis Gomez", "Maria Rios", "Carlos Vega", "Sofia Paz", "Diego Luna", "Lucia Mora", "Pedro Salas", "Elena Cruz", "Jorge Diaz" };
            string[] e = { "En lavado", "Listo para recoger", "Recogido", "En lavado", "Listo para recoger" };
            string[] p = { "Pagado", "Pendiente", "Pagado", "Pagado", "Pendiente" };
            double[] d = { 0, 5.50, 0, 0, 3.50 };
            int[] prendas = { 3, 8, 5, 2, 12 };
            string[] os = { "Lavado al agua", "Lavado al seco", "Teñido", "Lavado al agua", "Lavado al seco" };
            string[] dp = { "Tiene detalles", "Sin detalles", "tiene una rotura", "esta rasgada la manga", "le falta un boton" };

            // === SECCIÓN PERSISTENCIA: LEER ARCHIVO TXT SI EXISTE ===

            // Le pedimos al sistema operativo  la ruta exacta de la carpeta "Mis Documentos"
            string documentos = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string carpetaApp = Path.Combine(documentos, "MiSistemaDeControl");
            bool archivoCargado = false;

            if (Directory.Exists(carpetaApp))
            {
                DirectoryInfo directorio = new DirectoryInfo(carpetaApp);
                FileInfo[] archivos = directorio.GetFiles("reporte_*.txt");
                FileInfo ultimoArchivo = archivos.OrderByDescending(f => f.LastWriteTime).FirstOrDefault();

                if (ultimoArchivo != null)
                {
                    try
                    {
                        string[] lineas = File.ReadAllLines(ultimoArchivo.FullName);
                        int tActual = 0;

                        foreach (string linea in lineas)
                        {
                            if (linea.StartsWith("Ticket #"))
                            {
                                string[] partesCortadas = linea.Split('|');

                                if (partesCortadas.Length >= 7)
                                {
                                    string parteTicket = partesCortadas[0].Replace("Ticket #", "").Trim();
                                    if (int.TryParse(parteTicket, out tActual))
                                    {
                                        // Expandimos la lista dinámicamente según el número del ticket
                                        AsegurarCapacidadLista(tActual);

                                        nombres[tActual] = partesCortadas[1].Trim();
                                        cantidadPrendas[tActual] = int.Parse(partesCortadas[2].Replace("cant.P:", "").Replace("cant.P: ", "").Trim());
                                        detallesPrenda[tActual] = partesCortadas[3].Replace("detalle:", "").Replace("detalle: ", "").Trim();
                                        opcion_servicio[tActual] = partesCortadas[4].Replace("T.servicio :", "").Trim();
                                        estados[tActual] = partesCortadas[5].Trim();

                                        string partePago = partesCortadas[6].Trim();
                                        if (partePago.StartsWith("Falta S/."))
                                        {
                                            pagos[tActual] = "Pendiente";
                                            deuda[tActual] = double.Parse(partePago.Replace("Falta S/.", "").Trim());
                                        }
                                        else
                                        {
                                            pagos[tActual] = "Pagado";
                                            deuda[tActual] = 0;
                                        }

                                        if (tActual >= ticket) ticket = tActual + 1;
                                    }
                                }
                            }
                            else if (linea.StartsWith("Total recaudado:   S/."))
                            {
                                double.TryParse(linea.Replace("Total recaudado:   S/.", "").Trim(), out total);
                            }
                        }
                        archivoCargado = true;
                        Console.WriteLine("¡Se recuperaron los datos del último reporte guardado en disco con éxito!");
                        Console.WriteLine($"Continuando desde el Ticket #{ticket}. Presione una tecla...");
                        Console.ReadKey();
                    }
                    catch (Exception)
                    {
                        nombres.Clear(); estados.Clear(); pagos.Clear(); deuda.Clear();
                        cantidadPrendas.Clear(); opcion_servicio.Clear(); detallesPrenda.Clear();
                        AlineadorIndiceCero();
                    }
                }
            }

            // Si no existía archivo previo, cargamos los 50 simulados directamente con corchetes
            if (!archivoCargado)
            {
                for (int i = 1; i <= 50; i++)
                {
                    AsegurarCapacidadLista(i);

                    nombres[i] = n[(i - 1) % 10];
                    estados[i] = e[(i - 1) % 5];
                    pagos[i] = p[(i - 1) % 5];
                    deuda[i] = d[(i - 1) % 5];
                    cantidadPrendas[i] = prendas[(i - 1) % 5];
                    opcion_servicio[i] = os[(i - 1) % 5];
                    detallesPrenda[i] = dp[(i - 1) % 5];

                    if (pagos[i] == "Pagado")
                    {
                        total += 20.00;
                    }
                    else if (pagos[i] == "Pendiente")
                    {
                        total += (20.00 - deuda[i]);
                    }
                }
                ticket = 51;
            }

            do
            {
                Console.Clear();
                Console.WriteLine("============================");
                Console.WriteLine("      SISTEMA MR. WASH      ");
                Console.WriteLine("============================");
                Console.WriteLine("1. Nuevo pedido");
                Console.WriteLine("2. Ver historial");
                Console.WriteLine("3. Confirmar recojo");
                Console.WriteLine("4. Cierre del dia");
                Console.WriteLine("5. Salir");
                Console.WriteLine("============================");
                Console.Write("Opcion: ");

                // implementamos tryparse y doubleparse para evitar caídas del programa ante ingresos de datos vacíos o nulos
                while (int.TryParse(Console.ReadLine(), out opcion) == false || opcion < 1 || opcion > 5)
                {
                    Console.WriteLine("\n¡Error: Opcion no valida! Debe ingresar un numero del 1 al 5.");
                    Console.Write("Intente de nuevo: ");
                }

                switch (opcion)
                {
                    case 1:
                        NuevoPedido(ref ticket, ref total);
                        break;
                    case 2:
                        VerHistorial(ticket);
                        break;
                    case 3:
                        ConfirmarRecojo(ticket, ref total);
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("=======================================");
                        Console.WriteLine("            CIERRE DEL DIA             ");
                        Console.WriteLine("=======================================");
                        Console.WriteLine($"Tickets atendidos: {ticket - 1}");
                        Console.WriteLine($"Total ya recaudado: S/. {total.ToString("F2")}");
                        Console.WriteLine("---------------------------------------");
                        //creamos la seccion de deudores y la cantidad aprox de dinero si pagan 
                        int cantidadDeudores = 0;
                        double totalPorCobrar = 0;

                        for (int i = 1; i < deuda.Count; i++)
                        {
                            if (deuda[i] > 0)
                            {
                                cantidadDeudores++;
                                totalPorCobrar += deuda[i];
                            }
                        }

                        double totalEstimadoFaltante = total + totalPorCobrar;

                        Console.WriteLine($"Clientes que deben:  {cantidadDeudores}");
                        Console.WriteLine($"Monto por cobrar:    S/. {totalPorCobrar.ToString("F2")}");
                        Console.WriteLine("---------------------------------------");
                        Console.WriteLine($"Total Proyectado:    S/. {totalEstimadoFaltante.ToString("F2")}");
                        Console.WriteLine("  (Si todos los pendientes pagaran)");
                        Console.WriteLine("=======================================");

                        Console.WriteLine("\nPresione una tecla para regresar al menú...");
                        Console.ReadKey();
                        break;

                    case 5:
                        Console.Clear();
                        Console.WriteLine("Cerrando el sistema de forma segura...");

                        documentos = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                        //Une de forma segura la ruta de Mis Documentos con el nombre de la carpeta MiSistemaDeControl
                        carpetaApp = Path.Combine(documentos, "MiSistemaDeControl");

                        //verificamos si la carpeta no  existe
                        if (!Directory.Exists(carpetaApp))
                        {
                            Directory.CreateDirectory(carpetaApp);
                        }
                        //creamos un nombre unico basandonos en la fecha 
                        string fechaActual = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
                        string nombreArchivo = $"reporte_{fechaActual}.txt";
                        string rutaCompleta = Path.Combine(carpetaApp, nombreArchivo);

                        Console.WriteLine($"Generando reporte de control en: {rutaCompleta}...");

                        //creamos una lista para almacenar renglones de texto uno por uno antes de guardarlos en el archivo físico
                        List<string> lineasReporte = new List<string>();
                        lineasReporte.Add("=== REPORTE DE CONTROL - CIERRE DE SISTEMA ===");
                        lineasReporte.Add("Fecha y hora de cierre: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        lineasReporte.Add($"Total recaudado:   S/.{total.ToString("F2")}");
                        lineasReporte.Add("-----------------------------------------------");
                        lineasReporte.Add("CLIENTES REGISTRADOS EN ESTA SESIÓN:");

                        for (int i = 1; i < nombres.Count; i++)
                        {
                            if (nombres[i] != null)
                            {
                                string textoPago = (pagos[i] == "Pendiente") ? "Falta S/." + deuda[i].ToString("F2") : "Pagado";
                                lineasReporte.Add("Ticket #" + i + "| " + nombres[i] + " |cant.P: " + cantidadPrendas[i] + " |detalle: " + detallesPrenda[i] + " |T.servicio :" + opcion_servicio[i] + " | " + estados[i] + " | " + textoPago + " |");
                                lineasReporte.Add("-------------------------------------------------------------------------------------");
                            }
                        }

                        try //usamos try com protefccion si el codigo falla no explote el programa 
                        {
                            File.WriteAllLines(rutaCompleta, lineasReporte);
                            Console.WriteLine("\n¡Datos guardados con éxito en Documentos/MiSistemaDeControl!");
                        }
                        // usamos catch par atrapar el problema del try y buscar una solucion y mostramos mensaje de tal error 
                        catch (Exception ex)
                        {
                            Console.WriteLine("\nError al guardar el archivo: " + ex.Message);//
                        }

                        Console.WriteLine("\nGracias por usar el sistema. Presione cualquier tecla para salir...");
                        Console.ReadKey();
                        break;
                }

            } while (opcion != 5);

            Console.WriteLine("Hasta luego!");
            Console.ReadKey();
        }

        // =============================================
        // REGISTRAR UN NUEVO PEDIDO 
        // =============================================
        static void NuevoPedido(ref int ticket, ref double totalDia)
        {
            Console.Clear();
            Console.WriteLine("--- NUEVO PEDIDO  Ticket #" + ticket + " ---");
            Console.WriteLine("(Escriba '0' o 'cancelar' en cualquier pregunta para salir)\n");

            string entrada; // Variable auxiliar para evaluar las entradas rápidas

            // 1. NOMBRE DEL CLIENTE
            string nombre;
            bool nombreInvalido;
            do
            {
                nombreInvalido = false;
                Console.Write("Nombre del cliente: ");
                nombre = Console.ReadLine();

                if (nombre == "0" || nombre.ToLower() == "cancelar") return;

                if (string.IsNullOrWhiteSpace(nombre))
                {
                    nombreInvalido = true;
                    Console.WriteLine("¡Error: El nombre del cliente no puede quedar vacío!");
                    continue;
                }
                for (int i = 0; i < nombre.Length; i++)
                {
                    if (nombre[i] >= '0' && nombre[i] <= '9')
                    {
                        nombreInvalido = true;
                        break;
                    }
                }
                if (nombreInvalido == true)
                {
                    Console.WriteLine("¡Error: El nombre no puede contener numeros!");
                }
            } while (nombreInvalido == true);

            // 2. CANTIDAD DE PRENDAS
            Console.Write("Cantidad de prendas: ");
            entrada = Console.ReadLine();
            if (entrada == "0" || entrada.ToLower() == "cancelar") return;

            int prendas;
            //pasamos el valor de entrada a prendas con out 
            while (int.TryParse(entrada, out prendas) == false || prendas <= 0)
            {
                Console.WriteLine("¡Error: Ingrese una cantidad de prendas valida (numeros mayores a 0)!");
                Console.Write("Cantidad de prendas: ");
                entrada = Console.ReadLine();
                if (entrada == "0" || entrada.ToLower() == "cancelar") return;
                //aqui si el usuario ingresa ejemplo 5 y como ya correcto el buble da la vuelta y lo almacena en prendas 
            }

            // 3. PESO EN KG
            Console.Write("Peso en kg: ");
            entrada = Console.ReadLine();
            if (entrada == "0" || entrada.ToLower() == "cancelar") return;

            double peso;
            while (double.TryParse(entrada, out peso) == false || peso <= 0)
            {
                Console.WriteLine("¡Error: Ingrese un peso valido (numeros mayores a 0)!");
                Console.Write("Peso en kg: ");
                entrada = Console.ReadLine();
                if (entrada == "0" || entrada.ToLower() == "cancelar") return;
            }

            // 4. DETALLES DE PRENDA
            Console.WriteLine("________________________________");
            Console.WriteLine("\n¿La prenda tiene algún detalle / defecto?");
            Console.WriteLine("1. Sí");
            Console.WriteLine("2. No");
            Console.WriteLine("3. Especificar detalle personalizado");
            Console.Write("Seleccione una opción (1-3): ");

            string opcion = Console.ReadLine();
            if (opcion == "0" || opcion.ToLower() == "cancelar") return;

            while (opcion != "1" && opcion != "2" && opcion != "3")
            {
                Console.WriteLine("¡Opción no válida!");
                Console.Write("Seleccione una opción (1-3): ");
                opcion = Console.ReadLine();
                if (opcion == "0" || opcion.ToLower() == "cancelar") return;
            }

            string detalleAsignado = "";
            switch (opcion)
            {
                case "1":
                    detalleAsignado = "Tiene detalles";
                    break;
                case "2":
                    detalleAsignado = "Sin detalles";
                    break;
                case "3":
                    Console.WriteLine("Describa el detalle de la prenda (ej. Manchado, botón roto): ");
                    detalleAsignado = Console.ReadLine();
                    if (detalleAsignado == "0" || detalleAsignado.ToLower() == "cancelar") return;
                    break;
            }

            // 5. SELECCIÓN DE SERVICIO
            Console.Clear();
            Console.WriteLine("---SELECCION DE SERVICIO---");
            Console.WriteLine("\nTipo de servicio:");
            Console.WriteLine("  1. Lavado al agua  S/.5.00/kg");
            Console.WriteLine("  2. Lavado al seco  S/.8.00/kg");
            Console.WriteLine("  3. Teñido          S/.10.00/kg");
            Console.Write("Opcion: ");

            entrada = Console.ReadLine();
            if (entrada == "0" || entrada.ToLower() == "cancelar") return;

            int servOp;
            while (int.TryParse(entrada, out servOp) == false || servOp < 1 || servOp > 3)
            {
                Console.WriteLine("¡Error: Seleccione un servicio valido (1, 2 o 3)!");
                Console.Write("Opcion: ");
                entrada = Console.ReadLine();
                if (entrada == "0" || entrada.ToLower() == "cancelar") return;
            }

            string servicio;
            double precio;
            if (servOp == 1) { servicio = "Lavado al agua"; precio = 5; }
            else if (servOp == 2) { servicio = "Lavado al seco"; precio = 8; }
            else { servicio = "Teñido"; precio = 10; }

            double totalPedido = peso * precio;
            double descuento = 0;

            if (totalPedido > 30)
            {
                Console.WriteLine($"\nEl pedido supera los S/.30.00 (Monto actual: S/.{totalPedido.ToString("F2")})");
                Console.WriteLine("¿Desea aplicar el descuento del 10%?");
                Console.WriteLine("  1. Sí, aplicar");
                Console.WriteLine("  2. No, mantener precio regular");
                Console.Write("Seleccione una opción (1-2): ");

                string opDescuento = Console.ReadLine();
                if (opDescuento == "0" || opDescuento.ToLower() == "cancelar") return;

                while (opDescuento != "1" && opDescuento != "2")
                {
                    Console.WriteLine("¡Opción no válida! Ingrese 1 para Sí o 2 para No.");
                    Console.Write("Seleccione una opción (1-2): ");
                    opDescuento = Console.ReadLine();
                    if (opDescuento == "0" || opDescuento.ToLower() == "cancelar") return;
                }

                if (opDescuento == "1")
                {
                    descuento = totalPedido * 0.10;
                    totalPedido = totalPedido - descuento;
                    Console.WriteLine("\n¡Descuento aplicado con éxito!");
                }
                else
                {
                    Console.WriteLine("\nSe mantuvo el precio regular.");
                }
            }

            // 6. DÍAS DE ENTREGA
            Console.Clear();
            Console.Write("Dias estimados de entrega (1-30): ");
            entrada = Console.ReadLine();
            if (entrada == "0" || entrada.ToLower() == "cancelar") return;

            int dias;
            while (int.TryParse(entrada, out dias) == false || dias < 1 || dias > 30)
            {
                Console.WriteLine("¡Error: Ingrese un numero de dias valido (1 a 30)!");
                Console.Write("Dias estimados de entrega (1-30): ");
                entrada = Console.ReadLine();
                if (entrada == "0" || entrada.ToLower() == "cancelar") return;
            }

            // 7. MONTO DE PAGO
            Console.Clear();
            Console.WriteLine("-tecla (C) para salir   ");
            Console.WriteLine("Total a pagar: S/." + totalPedido.ToString("F2"));
            Console.Write("Monto que paga el cliente: S/.");
            entrada = Console.ReadLine();
            if (entrada == "c" || entrada == "C" || entrada.ToLower() == "cancelar") return;

            double montoPago;
            while (double.TryParse(entrada, out montoPago) == false || montoPago < 0)
            {
                Console.WriteLine("¡Error: Ingrese un monto de dinero valido!");
                Console.Write("Monto que paga el cliente: S/.");
                entrada = Console.ReadLine();
                if (entrada == "c" || entrada == "C" || entrada.ToLower() == "cancelar") return;
            }

            double vuelto = 0;
            double falta = 0;
            string estadoPago;

            if (montoPago >= totalPedido)
            {
                vuelto = montoPago - totalPedido;
                estadoPago = "Pagado";
                totalDia += totalPedido;
            }
            else
            {
                falta = totalPedido - montoPago;
                estadoPago = "Pendiente";
                totalDia += montoPago;
            }

            // Muestra Boleta final
            Console.Clear();
            Console.WriteLine("================================");
            Console.WriteLine("          BOLETA DE PAGO         ");
            Console.WriteLine("================================");
            Console.WriteLine("Ticket:    #" + ticket);
            Console.WriteLine("Cliente:   " + nombre);
            Console.WriteLine("Servicio:  " + servicio);
            Console.WriteLine("Prendas:   " + prendas);
            Console.WriteLine("Detalle:   " + detalleAsignado);
            Console.WriteLine("Peso:      " + peso + " kg");
            Console.WriteLine("Descuento: S/." + descuento.ToString("F2"));
            Console.WriteLine("Total:     S/." + totalPedido.ToString("F2"));
            Console.WriteLine("Pago:      " + estadoPago);

            if (estadoPago == "Pagado")
                Console.WriteLine("Vuelto:    S/." + vuelto.ToString("F2"));
            else
                Console.WriteLine("Falta:     S/." + falta.ToString("F2"));

            Console.WriteLine("Entrega en " + dias + " dia(s)");
            Console.WriteLine("Estado:    En lavado");
            Console.WriteLine("================================");
            Console.WriteLine("\nPresione una tecla para guardar...");
            Console.ReadKey();

            // Guardado efectivo en las listas
            AsegurarCapacidadLista(ticket);
            //lo guardamos en las lista globales
            nombres[ticket] = nombre;
            estados[ticket] = "En lavado";
            cantidadPrendas[ticket] = prendas;
            pagos[ticket] = estadoPago;
            deuda[ticket] = falta;
            opcion_servicio[ticket] = servicio;
            detallesPrenda[ticket] = detalleAsignado;

            ticket++; // El ticket aumenta solo si se llegó hasta aquí con éxito
        }

        // =============================================
        // VER HISTORIAL DE TODOS LOS TICKETS
        // =============================================
        static void VerHistorial(int ticket)
        {
            Console.Clear();
            Console.WriteLine("===== HISTORIAL =====");

            if (ticket == 1)
            {
                Console.WriteLine("No hay pedidos aun.");
            }
            else
            {
                for (int i = 1; i <= ticket - 1; i++)
                {
                    Console.Write("Ticket #" + i + "|" + nombres[i] + "|cant.P: " + cantidadPrendas[i] + "|detalle: " + detallesPrenda[i] + "|T.servicio :" + opcion_servicio[i] + "|" + estados[i] + "|");

                    if (pagos[i] == "Pendiente")
                        Console.WriteLine("Falta S/." + deuda[i].ToString("F2"));
                    else
                        Console.WriteLine("Pagado");
                    Console.WriteLine("-------------------------------------------------------------------------------------");
                }
            }

            Console.WriteLine("=====================");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
        }

        // =============================================
        // CONFIRMAR RECOJO DE UN PEDIDO
        // =============================================
        static void ConfirmarRecojo(int ticket, ref double totalDia)
        {
            Console.Clear();
            Console.WriteLine("--- CONFIRMAR RECOJO ---");
            if (ticket == 1)
            {
                Console.WriteLine("No hay pedidos aun.");
                Console.WriteLine("\nPresione una tecla...");
                Console.ReadKey();
                return;
            }

            Console.Write("Numero de ticket (1-" + (ticket - 1) + "): ");

            int num;
            while (int.TryParse(Console.ReadLine(), out num) == false || num < 1 || num >= ticket)
            {
                Console.WriteLine("\n¡Error: El número de ticket no es válido o no existe!");
                Console.Write("Ingrese un numero de ticket correcto (1-" + (ticket - 1) + "): ");
            }

            Console.Clear();
            Console.WriteLine("Ticket:  #" + num);
            Console.WriteLine("Cliente: " + nombres[num]);
            Console.WriteLine("Estado:  " + estados[num]);

            if (pagos[num] == "Pendiente")
                Console.WriteLine("Pago:    Falta S/." + deuda[num].ToString("F2"));
            else
                Console.WriteLine("Pago:    Pagado");

            Console.WriteLine("------------------------");

            if (estados[num] == "En lavado")
            {
                Console.WriteLine("1. Marcar como Listo para recoger");
                Console.WriteLine("2. Cancelar");
                Console.Write("Opcion: ");

                int op;
                while (int.TryParse(Console.ReadLine(), out op) == false || (op != 1 && op != 2))
                {
                    Console.WriteLine("¡Error: Seleccione una opcion valida (1 o 2)!");
                    Console.Write("Opcion: ");
                }

                if (op == 1)
                {
                    estados[num] = "Listo para recoger";
                    Console.WriteLine("Actualizado: Listo para recoger");
                }
                else
                {
                    Console.WriteLine("Sin cambios.");
                }
            }
            else if (estados[num] == "Listo para recoger")
            {
                Console.WriteLine("1. Marcar como Recogido y pagado");
                Console.WriteLine("2. Sin cambios");
                Console.Write("Opcion: ");

                int op;
                while (int.TryParse(Console.ReadLine(), out op) == false || (op != 1 && op != 2))
                {
                    Console.WriteLine("¡Error: Seleccione una opcion valida (1 o 2)!");
                    Console.Write("Opcion: ");
                }

                if (op == 1)
                {
                    estados[num] = "Recogido";
                    pagos[num] = "Pagado";
                    totalDia += deuda[num];
                    deuda[num] = 0;
                    Console.WriteLine("Actualizado: Recogido y Pagado");
                }
                else
                {
                    Console.WriteLine("Sin cambios.");
                }
            }
            else if (estados[num] == "Recogido")
            {
                Console.WriteLine("Este pedido ya fue recogido.");
            }

            Console.WriteLine("------------------------");
            Console.WriteLine("\nPresione una tecla...");
            Console.ReadKey();
        }

        // =======================================================================
        // MÉTODOS DE APOYO
        // =======================================================================
        static void AlineadorIndiceCero()
        {
            nombres.Add(""); estados.Add(""); pagos.Add(""); deuda.Add(0);
            cantidadPrendas.Add(0); opcion_servicio.Add(""); detallesPrenda.Add("");
        }

        static void AsegurarCapacidadLista(int indiceRequerido)
        {
            while (nombres.Count <= indiceRequerido)
            {
                nombres.Add(""); estados.Add(""); pagos.Add(""); deuda.Add(0);
                cantidadPrendas.Add(0); opcion_servicio.Add(""); detallesPrenda.Add("");
            }
        }
    }
}